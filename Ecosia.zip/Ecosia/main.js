const { Menu, app, BrowserWindow } = require('electron');
const config = require("./config");
const path = require('path');

console.log("App started");
function createWindow () {
  const win = new BrowserWindow({
    width: config.width,
    height: config.height,
    show: config.show,
    frame: config.frame,
    webPreferences: {
      nodeIntegration: true
    },
    icon: path.join(__dirname, 'ecosia.png'),
    title: "Ecosia"
  });
  win.loadURL(config.url);
  Menu.setApplicationMenu(null);
}

app.whenReady().then(createWindow)

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit();
    }
})
  
app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
})
