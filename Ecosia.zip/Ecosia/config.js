module.exports = {
    url: "https://www.ecosia.org/",
    frame: true,
    show: true,
    width: 1200,
    height: 720
}