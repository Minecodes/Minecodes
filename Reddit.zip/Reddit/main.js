const { Menu, app, BrowserWindow } = require('electron')
const path = require('path')

console.log("App started");
function createWindow () {
  const win = new BrowserWindow({
    width: 1200,
    height: 720,
    show: true,
    frame: true,
    webPreferences: {
      nodeIntegration: true
    },
    icon: path.join(__dirname, 'icon.ico')
  })
  win.loadURL('https://reddit.com')
  Menu.setApplicationMenu(null)
}

app.whenReady().then(createWindow)

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit()
    }
})
  
app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
})
